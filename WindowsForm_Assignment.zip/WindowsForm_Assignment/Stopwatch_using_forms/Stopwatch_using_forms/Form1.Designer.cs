﻿
namespace Stopwatch_using_forms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Strtbutton = new System.Windows.Forms.Button();
            this.stpbtn = new System.Windows.Forms.Button();
            this.result = new System.Windows.Forms.RichTextBox();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // Strtbutton
            // 
            this.Strtbutton.Location = new System.Drawing.Point(99, 110);
            this.Strtbutton.Name = "Strtbutton";
            this.Strtbutton.Size = new System.Drawing.Size(75, 23);
            this.Strtbutton.TabIndex = 0;
            this.Strtbutton.Text = "Start";
            this.Strtbutton.UseVisualStyleBackColor = true;
            this.Strtbutton.Click += new System.EventHandler(this.Strtbutton_Click);
            // 
            // stpbtn
            // 
            this.stpbtn.Location = new System.Drawing.Point(217, 110);
            this.stpbtn.Name = "stpbtn";
            this.stpbtn.Size = new System.Drawing.Size(75, 23);
            this.stpbtn.TabIndex = 1;
            this.stpbtn.Text = "Stop";
            this.stpbtn.UseVisualStyleBackColor = true;
            this.stpbtn.Click += new System.EventHandler(this.stpbtn_Click);
            // 
            // result
            // 
            this.result.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.result.ForeColor = System.Drawing.Color.Black;
            this.result.Location = new System.Drawing.Point(82, 25);
            this.result.Name = "result";
            this.result.ReadOnly = true;
            this.result.Size = new System.Drawing.Size(231, 44);
            this.result.TabIndex = 2;
            this.result.Text = " 00:00:00";
            this.result.TextChanged += new System.EventHandler(this.result_TextChanged);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(82, 164);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(231, 23);
            this.progressBar1.TabIndex = 3;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(455, 265);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.result);
            this.Controls.Add(this.stpbtn);
            this.Controls.Add(this.Strtbutton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Strtbutton;
        private System.Windows.Forms.Button stpbtn;
        private System.Windows.Forms.RichTextBox result;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Timer timer1;
    }
}

